const nodes = [
  [8, 24], [18, 58], [29, 16], [38, 43], [49, 75], [57, 25], [68, 53], [78, 18], [88, 69], [96, 37],
  [12, 83], [25, 74], [44, 12], [63, 86], [73, 73], [84, 46], [93, 88],
] as const;

const links = [
  [0, 1], [0, 2], [1, 3], [1, 10], [2, 3], [2, 5], [3, 4], [3, 5], [4, 6], [4, 11],
  [5, 6], [5, 7], [6, 8], [6, 14], [7, 9], [7, 13], [8, 9], [8, 12], [9, 16], [10, 11],
  [11, 12], [12, 4], [12, 13], [13, 14], [14, 15], [15, 16], [8, 16],
] as const;

export default function NetworkBackground() {
  return (
    <div className="network-bg" aria-hidden="true">
      <div className="network-glow network-glow-one" />
      <div className="network-glow network-glow-two" />
      <svg className="network-lines" viewBox="0 0 100 100" preserveAspectRatio="none">
        {links.map(([from, to], index) => (
          <line
            key={`${from}-${to}`}
            className="network-line"
            style={{ animationDelay: `${index * -0.7}s` }}
            x1={nodes[from][0]}
            y1={nodes[from][1]}
            x2={nodes[to][0]}
            y2={nodes[to][1]}
          />
        ))}
        {nodes.map(([x, y], index) => (
          <g key={`${x}-${y}`} className="network-node" style={{ animationDelay: `${index * -0.45}s` }}>
            <circle cx={x} cy={y} r="1.1" />
            <circle className="network-node-core" cx={x} cy={y} r="0.35" />
          </g>
        ))}
      </svg>
      <div className="network-noise" />
    </div>
  );
}
