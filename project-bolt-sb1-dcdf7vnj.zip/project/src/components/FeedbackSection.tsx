import { useState, type FormEvent } from 'react';
import { ArrowUpRight, CheckCircle2, MessageSquare, Send } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useI18n } from '@/lib/i18n';

export default function FeedbackSection() {
  const { lang } = useI18n();
  const [message, setMessage] = useState('');
  const [status, setStatus] = useState<'idle' | 'sending' | 'sent' | 'error'>('idle');

  const submit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!message.trim()) return;

    setStatus('sending');
    const { error } = await supabase.from('feedback').insert({ message: message.trim() });
    setStatus(error ? 'error' : 'sent');
    if (!error) setMessage('');
  };

  const uz = lang === 'uz';

  return (
    <section className="feedback-grid mt-10">
      <div className="feedback-intro">
        <div className="eyebrow"><MessageSquare className="h-4 w-4" /> {uz ? 'Ochiq aloqa' : 'Open channel'}</div>
        <h2>{uz ? 'Fikringiz keyingi darsni shakllantiradi.' : 'Your feedback shapes the next lesson.'}</h2>
        <p>{uz ? 'Savol, taklif yoki tushunarsiz mavzu bormi? Bizga yozing — PHYUZ yanada foydali bo‘lib boradi.' : 'Have a question, idea, or confusing topic? Send it in and help PHYUZ become more useful.'}</p>
        <a className="telegram-link" href="https://t.me/NorqulovSohibjon" target="_blank" rel="noreferrer">
          <span className="telegram-mark">TG</span>
          <span><b>@NorqulovSohibjon</b><small>{uz ? 'Telegram orqali bog‘lanish' : 'Reach out on Telegram'}</small></span>
          <ArrowUpRight className="ml-auto h-4 w-4" />
        </a>
      </div>

      <form className="feedback-card" onSubmit={submit}>
        <div className="feedback-card-header">
          <div><span className="section-kicker">01 / {uz ? 'Fikr yuborish' : 'Send feedback'}</span><h3>{uz ? 'Nima haqida o‘ylayapsiz?' : 'What is on your mind?'}</h3></div>
          <span className="signal-dot" />
        </div>
        <textarea
          value={message}
          onChange={(event) => { setMessage(event.target.value); setStatus('idle'); }}
          maxLength={2000}
          placeholder={uz ? 'Savolingiz yoki taklifingizni yozing...' : 'Write your question or suggestion...'}
          aria-label={uz ? 'Fikr va savol' : 'Feedback and question'}
        />
        <div className="feedback-actions">
          <span>{message.length}/2000</span>
          <button className="send-button" type="submit" disabled={status === 'sending' || !message.trim()}>
            {status === 'sending' ? (uz ? 'Yuborilmoqda...' : 'Sending...') : <>{uz ? 'Yuborish' : 'Send'} <Send className="h-4 w-4" /></>}
          </button>
        </div>
        {status === 'sent' && <p className="feedback-success"><CheckCircle2 className="h-4 w-4" /> {uz ? 'Rahmat, xabaringiz qabul qilindi.' : 'Thanks, your message has been received.'}</p>}
        {status === 'error' && <p className="feedback-error">{uz ? 'Xabar yuborilmadi. Qayta urinib ko‘ring.' : 'Message not sent. Please try again.'}</p>}
      </form>
    </section>
  );
}
