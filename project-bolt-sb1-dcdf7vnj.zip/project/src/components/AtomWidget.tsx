import { Atom } from 'lucide-react';

export default function AtomWidget() {
  return (
    <div className="atom-widget">
      <div className="atom-glow" />
      <div className="atom-orbit atom-orbit-1">
        <span className="atom-electron" />
      </div>
      <div className="atom-orbit atom-orbit-2">
        <span className="atom-electron" />
      </div>
      <div className="atom-orbit atom-orbit-3">
        <span className="atom-electron" />
      </div>
      <div className="atom-nucleus">
        <Atom className="h-8 w-8" strokeWidth={1.5} />
      </div>
    </div>
  );
}
