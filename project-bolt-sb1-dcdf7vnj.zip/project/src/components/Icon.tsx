import {
  Home,
  Atom,
  Trophy,
  HelpCircle,
  Gamepad2,
  Waves,
  FlaskConical,
  BookOpen,
  BarChart3,
  Settings,
  Menu,
  Search,
  Moon,
  Sun,
  Play,
  ArrowRight,
  Clock,
  Flame,
  CheckCircle2,
  ChevronLeft,
  Video,
  Eye,
  Zap,
  Radiation,
  type LucideIcon,
} from 'lucide-react';

const topicIcons: Record<string, LucideIcon> = {
  Settings,
  FlaskConical,
  Zap,
  Eye,
  Radiation,
  Atom,
};

export function iconForTopic(name: string): LucideIcon {
  return topicIcons[name] ?? Atom;
}

export {
  Home,
  Atom,
  Trophy,
  HelpCircle,
  Gamepad2,
  Waves,
  FlaskConical,
  BookOpen,
  BarChart3,
  Settings,
  Menu,
  Search,
  Moon,
  Sun,
  Play,
  ArrowRight,
  Clock,
  Flame,
  CheckCircle2,
  ChevronLeft,
  Video,
};
