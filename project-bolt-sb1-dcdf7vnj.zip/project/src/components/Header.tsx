import { Menu, Search, Moon, Sun, Atom } from 'lucide-react';
import type { Lang, PageView } from '@/types/database';
import { useI18n } from '@/lib/i18n';

type Props = {
  onNavigate: (v: PageView) => void;
  onMenuClick: () => void;
  search: string;
  onSearch: (v: string) => void;
  theme: 'light' | 'dark';
  onToggleTheme: () => void;
};

export default function Header({
  onNavigate,
  onMenuClick,
  search,
  onSearch,
  theme,
  onToggleTheme,
}: Props) {
  const { lang, setLang, t } = useI18n();

  return (
    <header
      className="fixed inset-x-0 top-0 z-50 flex h-[var(--header-h)] items-center gap-3 border-b border-border px-4 backdrop-blur-md md:gap-5 md:px-6"
      style={{
        background: 'color-mix(in srgb, var(--c-surface) 90%, transparent)',
        ['--header-h' as string]: '64px',
      }}
    >
      <button
        className="icon-btn md:hidden"
        onClick={onMenuClick}
        aria-label="Menu"
      >
        <Menu className="h-5 w-5" strokeWidth={1.8} />
      </button>

      <button
        onClick={() => onNavigate('home')}
        className="flex shrink-0 items-center gap-2.5"
      >
        <div className="grid h-10 w-10 place-items-center rounded-xl bg-gradient-to-br from-primary to-accent text-white shadow-card">
          <Atom className="h-6 w-6" strokeWidth={1.8} />
        </div>
        <div className="hidden text-lg font-extrabold leading-tight tracking-tight text-text sm:block">
          PHY<span className="text-primary-2">UZ</span>
          <span className="block text-[0.7rem] font-medium tracking-wide text-muted">
            Physics Uzbekistan
          </span>
        </div>
      </button>

      <label className="relative mx-auto w-full max-w-[480px]" role="search">
        <Search
          className="absolute left-3.5 top-1/2 -translate-y-1/2 text-muted"
          size={18}
          strokeWidth={1.8}
        />
        <input
          type="search"
          value={search}
          onChange={(e) => onSearch(e.target.value)}
          placeholder={t('searchPh')}
          autoComplete="off"
          className="h-10 w-full rounded-xl border border-border bg-surface-2 pl-10 pr-4 text-sm text-text outline-none transition-all placeholder:text-muted focus:border-primary focus:bg-surface focus:ring-4 focus:ring-primary-soft"
        />
      </label>

      <div className="flex shrink-0 items-center gap-2">
        <div
          className="flex rounded-xl border border-border bg-surface-2 p-0.5"
          role="group"
          aria-label="Language"
        >
          {(['uz', 'en'] as Lang[]).map((l) => (
            <button
              key={l}
              onClick={() => setLang(l)}
              className={`rounded-lg px-2.5 py-1.5 text-xs font-semibold transition-all ${
                lang === l ? 'bg-primary text-white shadow-sm' : 'text-muted'
              }`}
            >
              {l === 'uz' ? 'O\u2019z' : 'En'}
            </button>
          ))}
        </div>

        <button
          className="icon-btn"
          onClick={onToggleTheme}
          aria-label={t('themeToggle')}
        >
          {theme === 'dark' ? (
            <Sun className="h-5 w-5" strokeWidth={1.8} />
          ) : (
            <Moon className="h-5 w-5" strokeWidth={1.8} />
          )}
        </button>

        <div className="hidden items-center gap-2.5 rounded-xl border border-border bg-surface-2 px-3 py-1.5 transition-colors hover:border-primary sm:flex">
          <div className="grid h-8 w-8 shrink-0 place-items-center rounded-lg bg-gradient-to-br from-primary to-accent text-xs font-bold text-white">
            SN
          </div>
          <div className="text-sm font-semibold leading-tight text-text">
            Sohibjon Norqulov
            <small className="block font-medium text-muted">{t('student')}</small>
          </div>
        </div>
      </div>
    </header>
  );
}
