import { ArrowRight, Play, Clock, CheckCircle2 } from 'lucide-react';
import type { Lang, Topic, Video } from '@/types/database';
import { iconForTopic } from '@/components/Icon';
import { useI18n } from '@/lib/i18n';

export function TopicCard({
  topic,
  lang,
  onClick,
}: {
  topic: Topic;
  lang: Lang;
  onClick: () => void;
}) {
  const { t } = useI18n();
  const Icon = iconForTopic(topic.icon);
  const title = lang === 'uz' ? topic.title_uz : topic.title_en;
  const desc = lang === 'uz' ? topic.description_uz : topic.description_en;

  return (
    <button onClick={onClick} className="card-hover card flex w-full flex-col gap-3 p-5 text-left">
      <div
        className="grid h-12 w-12 place-items-center rounded-2xl text-white"
        style={{ background: `linear-gradient(135deg, ${topic.color_from}, ${topic.color_to})` }}
      >
        <Icon className="h-6 w-6" strokeWidth={1.8} />
      </div>
      <h3 className="text-base font-bold text-text">{title}</h3>
      <p className="flex-1 text-sm text-muted">{desc}</p>
      <div className="flex items-center justify-between text-xs text-muted">
        <span>0 {t('lessons')}</span>
        <span>0%</span>
      </div>
      <div className="bar">
        <i style={{ width: '0%' }} />
      </div>
    </button>
  );
}

export function VideoCard({
  video,
  topic,
  lang,
  onPlay,
}: {
  video: Video;
  topic: Topic | undefined;
  lang: Lang;
  onPlay: () => void;
}) {
  const { t } = useI18n();
  const title = lang === 'uz' ? video.title_uz : video.title_en;
  const desc = lang === 'uz' ? video.description_uz : video.description_en;
  const topicTitle = topic ? (lang === 'uz' ? topic.title_uz : topic.title_en) : '';
  const published = video.status === 'published';

  return (
    <div className="card-hover card cursor-pointer overflow-hidden" onClick={onPlay}>
      <div
        className="relative grid aspect-video place-items-center border-b border-border"
        style={{
          background: `linear-gradient(135deg, var(--c-primary-soft), var(--c-surface-2))`,
        }}
      >
        <div className="grid h-12 w-12 place-items-center rounded-full bg-surface text-primary shadow-card transition-all group-hover:scale-110 group-hover:bg-primary group-hover:text-white">
          <Play className="h-5 w-5" fill="currentColor" stroke="none" />
        </div>
        {video.duration_label && (
          <span className="absolute bottom-2.5 right-2.5 rounded bg-black/70 px-2 py-0.5 text-xs font-semibold text-white">
            {video.duration_label}
          </span>
        )}
        {!published && (
          <span className="absolute left-2.5 top-2.5 rounded-full bg-accent-soft px-2.5 py-1 text-xs font-semibold text-accent">
            {t('comingSoon')}
          </span>
        )}
      </div>
      <div className="p-4">
        <h4 className="mb-1 text-sm font-semibold text-text">{title}</h4>
        <p className="text-xs text-primary-2">{topicTitle}</p>
        <p className="mt-1.5 text-xs leading-relaxed text-muted">{desc}</p>
      </div>
    </div>
  );
}

export function StatCard({
  icon: Icon,
  value,
  label,
  accent,
}: {
  icon: typeof Clock;
  value: string;
  label: string;
  accent?: boolean;
}) {
  return (
    <div className="card-hover card flex items-center gap-3.5 p-4">
      <div
        className={`grid h-11 w-11 place-items-center rounded-xl ${
          accent ? 'bg-accent-soft text-accent' : 'bg-primary-soft text-primary'
        }`}
      >
        <Icon className="h-5 w-5" strokeWidth={1.8} />
      </div>
      <div>
        <b className="block text-lg font-extrabold leading-tight text-text">{value}</b>
        <span className="text-xs text-muted">{label}</span>
      </div>
    </div>
  );
}

export function EmptyState({
  icon: Icon,
  title,
  description,
  action,
}: {
  icon: typeof Clock;
  title: string;
  description: string;
  action?: React.ReactNode;
}) {
  return (
    <div className="card px-7 py-14 text-center">
      <div className="mx-auto mb-4 grid h-16 w-16 place-items-center rounded-2xl bg-primary-soft text-primary">
        <Icon className="h-8 w-8" strokeWidth={1.8} />
      </div>
      <h2 className="mb-2 text-xl font-bold text-text">{title}</h2>
      <p className="mx-auto mb-5 max-w-md text-sm text-muted">{description}</p>
      {action}
    </div>
  );
}

export { ArrowRight, Play, Clock, CheckCircle2 };
