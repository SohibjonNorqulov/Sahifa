import { Home, Atom, Trophy, HelpCircle, Gamepad2, Waves, FlaskConical, BookOpen, BarChart3, Settings, Video } from 'lucide-react';
import type { PageView } from '@/types/database';
import { useI18n } from '@/lib/i18n';

type NavItem = {
  view: PageView;
  icon: typeof Home;
  labelKey: string;
};

const mainItems: NavItem[] = [
  { view: 'home', icon: Home, labelKey: 'home' },
  { view: 'general', icon: Atom, labelKey: 'general' },
  { view: 'videos', icon: Video, labelKey: 'videos' },
];

const contentItems: NavItem[] = [
  { view: 'olympiads', icon: Trophy, labelKey: 'olympiads' },
  { view: 'quizzes', icon: HelpCircle, labelKey: 'quizzes' },
  { view: 'games', icon: Gamepad2, labelKey: 'games' },
  { view: 'simulations', icon: Waves, labelKey: 'simulations' },
  { view: 'labs', icon: FlaskConical, labelKey: 'labs' },
  { view: 'library', icon: BookOpen, labelKey: 'library' },
];

const userItems: NavItem[] = [
  { view: 'results', icon: BarChart3, labelKey: 'results' },
];

const systemItems: NavItem[] = [
  { view: 'settings', icon: Settings, labelKey: 'settings' },
  { view: 'help', icon: HelpCircle, labelKey: 'help' },
];

type Props = {
  current: PageView;
  onNavigate: (view: PageView) => void;
  navOpen: boolean;
  onClose: () => void;
};

function NavRow({
  item,
  current,
  onNavigate,
  onClose,
}: {
  item: NavItem;
  current: PageView;
  onNavigate: (v: PageView) => void;
  onClose: () => void;
}) {
  const { t } = useI18n();
  const Icon = item.icon;
  const active = current === item.view;
  return (
    <button
      onClick={() => {
        onNavigate(item.view);
        onClose();
      }}
      className={`relative flex w-full items-center gap-3 rounded-xl px-4 py-3 text-left text-sm font-medium transition-all ${
        active
          ? 'bg-primary-soft font-semibold text-primary-2'
          : 'text-muted hover:bg-surface-2 hover:text-text'
      }`}
    >
      {active && (
        <span className="absolute -left-3.5 top-2 bottom-2 w-1 rounded-r-full bg-primary" />
      )}
      <Icon className="h-5 w-5 shrink-0" strokeWidth={1.8} />
      <span className="truncate">{t(item.labelKey)}</span>
    </button>
  );
}

export default function Sidebar({
  current,
  onNavigate,
  navOpen,
  onClose,
}: Props) {
  const { t } = useI18n();

  const renderGroup = (titleKey: string, items: NavItem[]) => (
    <div className="mb-5">
      <div className="px-4 pb-2.5 text-xs font-bold uppercase tracking-widest text-muted">
        {t(titleKey)}
      </div>
      <div className="space-y-0.5">
        {items.map((item) => (
          <NavRow
            key={item.view}
            item={item}
            current={current}
            onNavigate={onNavigate}
            onClose={onClose}
          />
        ))}
      </div>
    </div>
  );

  return (
    <>
      {/* Desktop sidebar — always visible, full width */}
      <aside
        className="sidebar-nav fixed bottom-0 top-16 z-40 hidden w-[var(--sidebar-w)] overflow-y-auto border-r border-border bg-surface p-4 md:block"
        style={{ ['--sidebar-w' as string]: '280px' }}
      >
        <nav>
          {renderGroup('gMain', mainItems)}
          {renderGroup('gContent', contentItems)}
          {renderGroup('gUser', userItems)}
          {renderGroup('gSystem', systemItems)}
        </nav>
      </aside>

      {/* Mobile drawer */}
      {navOpen && (
        <aside
          className="sidebar-nav fixed bottom-0 top-16 z-40 w-[var(--sidebar-w)] overflow-y-auto border-r border-border bg-surface p-4 md:hidden"
          style={{ ['--sidebar-w' as string]: '280px' }}
        >
          <nav>
            {renderGroup('gMain', mainItems)}
            {renderGroup('gContent', contentItems)}
            {renderGroup('gUser', userItems)}
            {renderGroup('gSystem', systemItems)}
          </nav>
        </aside>
      )}
    </>
  );
}
