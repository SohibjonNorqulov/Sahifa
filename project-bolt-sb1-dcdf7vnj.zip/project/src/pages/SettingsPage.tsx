import { Moon, Sun } from 'lucide-react';
import type { Lang } from '@/types/database';
import { useI18n } from '@/lib/i18n';

type Props = {
  lang: Lang;
  setLang: (l: Lang) => void;
  theme: 'light' | 'dark';
  onToggleTheme: () => void;
};

export default function SettingsPage({ lang, setLang, theme, onToggleTheme }: Props) {
  const { t } = useI18n();

  return (
    <div className="mx-auto max-w-[700px] animate-fade">
      <div className="mb-5">
        <div className="mb-2 text-sm text-muted">
          <span>{t('home')}</span> {' / '} <span>{t('settings')}</span>
        </div>
        <h1 className="mb-1.5 text-2xl font-extrabold text-text">{t('settings')}</h1>
        <p className="text-sm text-muted">{t('settingsSub')}</p>
      </div>

      <div className="card divide-y divide-border px-6">
        <div className="flex items-center justify-between gap-4 py-4">
          <div>
            <b className="block text-sm font-semibold text-text">{t('setLang')}</b>
            <span className="text-xs text-muted">{t('setLangSub')}</span>
          </div>
          <div className="flex rounded-xl border border-border bg-surface-2 p-0.5">
            {(['uz', 'en'] as Lang[]).map((l) => (
              <button
                key={l}
                onClick={() => setLang(l)}
                className={`rounded-lg px-3 py-1.5 text-xs font-semibold transition-all ${
                  lang === l ? 'bg-primary text-white shadow-sm' : 'text-muted'
                }`}
              >
                {l === 'uz' ? 'O\u2019z' : 'En'}
              </button>
            ))}
          </div>
        </div>

        <div className="flex items-center justify-between gap-4 py-4">
          <div>
            <b className="block text-sm font-semibold text-text">{t('setTheme')}</b>
            <span className="text-xs text-muted">{t('setThemeSub')}</span>
          </div>
          <button className="icon-btn" onClick={onToggleTheme} aria-label={t('themeToggle')}>
            {theme === 'dark' ? (
              <Sun className="h-5 w-5" strokeWidth={1.8} />
            ) : (
              <Moon className="h-5 w-5" strokeWidth={1.8} />
            )}
          </button>
        </div>
      </div>
    </div>
  );
}
