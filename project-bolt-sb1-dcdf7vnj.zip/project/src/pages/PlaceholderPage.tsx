import type { PageView } from '@/types/database';
import { useI18n } from '@/lib/i18n';
import { EmptyState } from '@/components/Cards';
import {
  Trophy,
  HelpCircle,
  Gamepad2,
  Waves,
  FlaskConical,
  BookOpen,
  BarChart3,
} from 'lucide-react';

const iconMap: Partial<Record<PageView, typeof Trophy>> = {
  olympiads: Trophy,
  quizzes: HelpCircle,
  games: Gamepad2,
  simulations: Waves,
  labs: FlaskConical,
  library: BookOpen,
  results: BarChart3,
  help: HelpCircle,
};

export default function PlaceholderPage({ view }: { view: PageView }) {
  const { t } = useI18n();
  const Icon = iconMap[view] ?? HelpCircle;

  return (
    <div className="mx-auto max-w-[900px] animate-fade">
      <EmptyState
        icon={Icon}
        title={t(view)}
        description={t('soon')}
        action={
          <div className="mt-6 grid gap-3.5 text-left sm:grid-cols-[repeat(auto-fill,minmax(200px,1fr))]">
            {[1, 2, 3].map((i) => (
              <div
                key={i}
                className="rounded-xl border-[1.5px] border-dashed border-border bg-surface-2 p-4"
              >
                <b className="mb-1 block text-sm font-semibold text-text">{t('slot')} {i}</b>
                <span className="text-xs text-muted">{t('slotSub')}</span>
              </div>
            ))}
          </div>
        }
      />
    </div>
  );
}
