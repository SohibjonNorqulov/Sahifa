import { useState } from 'react';
import { Play, X } from 'lucide-react';
import type { Lang, Topic, Video } from '@/types/database';
import { useI18n } from '@/lib/i18n';
import { VideoCard, EmptyState } from '@/components/Cards';

type Props = {
  videos: Video[];
  topicMap: Map<string, Topic>;
  lang: Lang;
  loading: boolean;
};

export default function VideosPage({ videos, topicMap, lang, loading }: Props) {
  const { t } = useI18n();
  const [active, setActive] = useState<Video | null>(null);

  return (
    <div className="mx-auto max-w-[1200px] animate-fade">
      <div className="mb-5">
        <div className="mb-2 text-sm text-muted">
          <span>{t('home')}</span> {' / '} <span>{t('videos')}</span>
        </div>
        <h1 className="mb-1.5 text-2xl font-extrabold text-text">{t('videos')}</h1>
        <p className="text-sm text-muted">{t('videosSub')}</p>
      </div>

      {loading ? (
        <div className="py-8 text-center text-sm text-muted">{t('loading')}</div>
      ) : videos.length === 0 ? (
        <EmptyState
          icon={Play}
          title={t('videos')}
          description={t('soon')}
        />
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {videos.map((v) => (
            <VideoCard
              key={v.id}
              video={v}
              topic={v.topic_id ? topicMap.get(v.topic_id) : undefined}
              lang={lang}
              onPlay={() => setActive(v)}
            />
          ))}
        </div>
      )}

      {/* Video modal */}
      {active && (
        <div
          className="fixed inset-0 z-[60] grid place-items-center bg-black/60 p-4 backdrop-blur-sm"
          onClick={() => setActive(null)}
        >
          <div
            className="card w-full max-w-3xl overflow-hidden bg-surface"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between border-b border-border p-4">
              <h3 className="text-base font-bold text-text">
                {lang === 'uz' ? active.title_uz : active.title_en}
              </h3>
              <button className="icon-btn" onClick={() => setActive(null)}>
                <X className="h-5 w-5" strokeWidth={1.8} />
              </button>
            </div>
            <div className="aspect-video bg-black">
              {active.youtube_id ? (
                <iframe
                  className="h-full w-full"
                  src={`https://www.youtube.com/embed/${active.youtube_id}`}
                  title={active.title_en}
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                  allowFullScreen
                />
              ) : (
                <div className="grid h-full place-items-center text-center text-muted">
                  <div>
                    <Play className="mx-auto mb-3 h-12 w-12 opacity-50" strokeWidth={1.5} />
                    <p className="text-sm text-text">{t('videoSoon')}</p>
                  </div>
                </div>
              )}
            </div>
            <div className="p-4">
              <p className="text-sm text-muted">
                {lang === 'uz' ? active.description_uz : active.description_en}
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
