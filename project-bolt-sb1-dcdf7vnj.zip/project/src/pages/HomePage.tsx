import { ArrowRight, Clock, Flame, HelpCircle, CheckCircle2, Atom } from 'lucide-react';
import type { Lang, PageView, Topic, Video } from '@/types/database';
import { useI18n } from '@/lib/i18n';
import { TopicCard, StatCard, VideoCard } from '@/components/Cards';
import FeedbackSection from '@/components/FeedbackSection';
import AtomWidget from '@/components/AtomWidget';

type Props = {
  topics: Topic[];
  videos: Video[];
  topicMap: Map<string, Topic>;
  loading: boolean;
  error: string | null;
  search: string;
  lang: Lang;
  onNavigate: (v: PageView) => void;
  onPlayVideo: (video: Video) => void;
};

export default function HomePage({
  topics,
  videos,
  topicMap,
  loading,
  error,
  search,
  lang,
  onNavigate,
  onPlayVideo,
}: Props) {
  const { t } = useI18n();

  const filtered = topics.filter((tp) => {
    if (!search) return true;
    const q = search.toLowerCase();
    return (
      tp.title_uz.toLowerCase().includes(q) ||
      tp.title_en.toLowerCase().includes(q) ||
      tp.description_uz.toLowerCase().includes(q) ||
      tp.description_en.toLowerCase().includes(q)
    );
  });

  return (
    <div className="mx-auto max-w-[1200px] animate-fade">
      {/* Hero */}
      <div className="hero-panel relative grid gap-6 overflow-hidden rounded-xl2 p-8 text-white md:p-10">
        <div className="hero-grid-lines" />
        <div className="relative z-10">
          <span className="chip">O'zbekcha · English</span>
          <h1 className="mt-3.5 mb-2.5 text-3xl font-extrabold leading-tight tracking-tight text-white">
            {t('heroTitle')}
          </h1>
          <p className="mb-5 max-w-[560px] text-base text-white/90">{t('heroText')}</p>
          <div className="flex flex-wrap gap-2.5">
            <button onClick={() => onNavigate('general')} className="btn bg-white text-[#0a0e14] shadow-md hover:-translate-y-0.5">
              {t('ctaStart')}
              <ArrowRight className="h-4 w-4" strokeWidth={1.8} />
            </button>
            <button onClick={() => onNavigate('quizzes')} className="btn-ghost">
              {t('ctaQuiz')}
            </button>
          </div>
        </div>
        <div className="relative z-10 hidden items-center justify-center md:grid">
          <AtomWidget />
        </div>
      </div>

      {/* Stats */}
      <div className="mt-6 grid grid-cols-2 gap-3 lg:grid-cols-4">
        <StatCard icon={CheckCircle2} value="0" label={t('stLessons')} />
        <StatCard icon={HelpCircle} value="0" label={t('stQuizzes')} accent />
        <StatCard icon={Clock} value={`0 ${t('hrs')}`} label={t('stHours')} />
        <StatCard icon={Flame} value={`0 ${t('days')}`} label={t('stStreak')} accent />
      </div>

      {/* Topics */}
      <div className="mb-4 mt-8 flex items-end justify-between gap-3">
        <div>
          <h2 className="text-xl font-bold text-text">{t('topicsTitle')}</h2>
          <span className="mt-1 text-sm text-muted">{t('topicsSub')}</span>
        </div>
        <button onClick={() => onNavigate('general')} className="inline-flex items-center gap-1 text-sm font-semibold text-primary-2 hover:underline">
          {t('viewAll')}
          <ArrowRight className="h-4 w-4" strokeWidth={1.8} />
        </button>
      </div>
      {loading ? (
        <div className="py-8 text-center text-sm text-muted">{t('loading')}</div>
      ) : error ? (
        <div className="py-8 text-center text-sm text-red-500">{t('error')}</div>
      ) : filtered.length === 0 ? (
        <div className="card p-7 text-center text-sm text-muted">{t('noResults')}</div>
      ) : (
        <div className="grid grid-cols-[repeat(auto-fill,minmax(220px,1fr))] gap-4">
          {filtered.map((tp) => (
            <TopicCard key={tp.id} topic={tp} lang={lang} onClick={() => onNavigate('general')} />
          ))}
        </div>
      )}

      {/* Videos + Progress */}
      <div className="mt-9 grid gap-5 lg:grid-cols-[1.6fr_1fr]">
        <div>
          <div className="mb-4">
            <h2 className="text-xl font-bold text-text">{t('videosTitle')}</h2>
            <p className="mt-1 text-sm text-muted">{t('videosSub')}</p>
          </div>
          <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
            {videos.slice(0, 3).map((v) => (
              <VideoCard
                key={v.id}
                video={v}
                topic={v.topic_id ? topicMap.get(v.topic_id) : undefined}
                lang={lang}
                onPlay={() => onPlayVideo(v)}
              />
            ))}
          </div>
        </div>
        <div>
          <div className="mb-4">
            <h2 className="text-xl font-bold text-text">{t('progressTitle')}</h2>
            <p className="mt-1 text-sm text-muted">{t('progressSub')}</p>
          </div>
          <div className="card p-5">
            <div className="mb-4 flex items-center gap-4 rounded-xl border border-border bg-surface-2 p-3.5">
              <div
                className="grid h-[82px] w-[82px] shrink-0 place-items-center rounded-full"
                style={{ background: 'conic-gradient(var(--c-primary) 0%, var(--c-border) 0)' }}
              >
                <div className="grid h-16 w-16 place-items-center rounded-full bg-surface-2 text-base font-extrabold text-text">
                  0%
                </div>
              </div>
              <div>
                <b className="block text-sm font-semibold text-text">{t('overall')}</b>
                <span className="text-xs text-muted">{t('overallSub')}</span>
              </div>
            </div>
            {topics.map((tp) => (
              <div key={tp.id} className="mb-3.5">
                <div className="mb-1.5 flex justify-between text-xs font-medium">
                  <span className="text-text">{lang === 'uz' ? tp.title_uz : tp.title_en}</span>
                  <span className="text-muted">0%</span>
                </div>
                <div className="bar">
                  <i style={{ width: '0%' }} />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* About */}
      <div className="card mt-8 grid gap-5 p-6 md:grid-cols-[auto_1fr]">
        <div className="grid h-[118px] w-[110px] place-items-center rounded-2xl bg-primary-soft text-primary-2">
          <Atom className="h-16 w-16" strokeWidth={1.35} />
        </div>
        <div>
          <h2 className="mb-2 text-lg font-bold text-text">{t('aboutTitle')}</h2>
          <p className="mb-2.5 text-sm text-muted">{t('aboutP1')}</p>
          <p className="text-sm text-muted" dangerouslySetInnerHTML={{ __html: t('aboutP2') }} />
          <div className="mt-3 flex flex-wrap gap-2">
            <span className="rounded-full bg-primary-soft px-3 py-1.5 text-xs font-semibold text-primary-2">{t('tagStudents')}</span>
            <span className="rounded-full bg-primary-soft px-3 py-1.5 text-xs font-semibold text-primary-2">{t('tagUni')}</span>
            <span className="rounded-full bg-primary-soft px-3 py-1.5 text-xs font-semibold text-primary-2">{t('tagTeachers')}</span>
            <span className="rounded-full bg-accent-soft px-3 py-1.5 text-xs font-semibold text-accent">{t('tagBilingual')}</span>
          </div>
        </div>
      </div>

      <FeedbackSection />

      <footer className="mt-11 text-center text-xs text-muted">
        {'\u00A9'} {new Date().getFullYear()} PHYUZ {'\u2014'} Physics Uzbekistan
      </footer>
    </div>
  );
}
