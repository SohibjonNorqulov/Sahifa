import type { Lang, Topic } from '@/types/database';
import { useI18n } from '@/lib/i18n';
import { iconForTopic } from '@/components/Icon';

type Props = {
  topics: Topic[];
  lang: Lang;
};

export default function GeneralPage({ topics, lang }: Props) {
  const { t } = useI18n();

  return (
    <div className="mx-auto max-w-[1000px] animate-fade">
      <div className="mb-5">
        <div className="mb-2 text-sm text-muted">
          <span>{t('home')}</span> {' / '} <span>{t('general')}</span>
        </div>
        <h1 className="mb-1.5 text-2xl font-extrabold text-text">{t('general')}</h1>
        <p className="text-sm text-muted">{t('generalSub')}</p>
      </div>

      <div className="grid gap-4">
        {topics.map((tp) => {
          const Icon = iconForTopic(tp.icon);
          const title = lang === 'uz' ? tp.title_uz : tp.title_en;
          const desc = lang === 'uz' ? tp.description_uz : tp.description_en;
          return (
            <div key={tp.id} className="card-hover card grid items-center gap-4 p-5 md:grid-cols-[auto_1fr_auto]">
              <div
                className="grid h-12 w-12 place-items-center rounded-2xl text-white"
                style={{ background: `linear-gradient(135deg, ${tp.color_from}, ${tp.color_to})` }}
              >
                <Icon className="h-6 w-6" strokeWidth={1.8} />
              </div>
              <div>
                <h3 className="mb-1 text-lg font-bold text-text">{title}</h3>
                <p className="text-sm text-muted">{desc}</p>
                <div className="mt-3 flex flex-wrap gap-2">
                  <span className="rounded-lg border border-border bg-surface-2 px-3 py-1.5 text-xs font-semibold text-muted">
                    {t('comingSoon')}
                  </span>
                </div>
              </div>
              <div className="md:text-right">
                <small className="text-xs text-muted">0 {t('lessons')} {'\xB7'} 0% {t('progress')}</small>
                <div className="bar mt-2">
                  <i style={{ width: '0%' }} />
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
