import { useEffect, useMemo, useState } from 'react';
import type { PageView } from '@/types/database';
import { I18nProvider, useI18n } from '@/lib/i18n';
import { useTheme } from '@/lib/useTheme';
import { useTopics, useVideos } from '@/lib/useContent';
import Header from '@/components/Header';
import Sidebar from '@/components/Sidebar';
import HomePage from '@/pages/HomePage';
import GeneralPage from '@/pages/GeneralPage';
import VideosPage from '@/pages/VideosPage';
import SettingsPage from '@/pages/SettingsPage';
import PlaceholderPage from '@/pages/PlaceholderPage';
import NetworkBackground from '@/components/NetworkBackground';

const placeholderViews: PageView[] = [
  'olympiads',
  'quizzes',
  'games',
  'simulations',
  'labs',
  'library',
  'results',
  'help',
];

function Shell() {
  const { lang, setLang } = useI18n();
  const { theme, toggle } = useTheme();

  const [view, setView] = useState<PageView>(() => {
    const hash = window.location.hash.slice(1) as PageView;
    return hash || 'home';
  });
  const [search, setSearch] = useState('');
  const [navOpen, setNavOpen] = useState(false);

  const { topics, loading, error } = useTopics();
  const { videos, loading: videosLoading } = useVideos();

  const topicMap = useMemo(() => {
    const m = new Map<string, (typeof topics)[number]>();
    topics.forEach((tp) => m.set(tp.id, tp));
    return m;
  }, [topics]);

  useEffect(() => {
    const onHash = () => {
      const hash = window.location.hash.slice(1) as PageView;
      if (hash) setView(hash);
    };
    window.addEventListener('hashchange', onHash);
    return () => window.removeEventListener('hashchange', onHash);
  }, []);

  const navigate = (v: PageView) => {
    setView(v);
    window.location.hash = v;
    setNavOpen(false);
    window.scrollTo({ top: 0 });
  };

  const isPlaceholder = placeholderViews.includes(view);

  return (
    <div className="min-h-screen bg-bg text-text">
      <NetworkBackground />
      <Header
        onNavigate={navigate}
        onMenuClick={() => setNavOpen((o) => !o)}
        search={search}
        onSearch={(v) => {
          setSearch(v);
          if (view !== 'home') navigate('home');
        }}
        theme={theme}
        onToggleTheme={toggle}
      />

      <Sidebar
        current={view}
        onNavigate={navigate}
        navOpen={navOpen}
        onClose={() => setNavOpen(false)}
      />

      {navOpen && (
        <div
          className="fixed inset-0 top-16 z-30 bg-black/50 md:hidden"
          onClick={() => setNavOpen(false)}
        />
      )}

      <main
        className="relative z-10 min-h-screen pt-[calc(var(--header-h)+28px)] md:ml-[var(--sidebar-w)]"
        style={{
          ['--header-h' as string]: '64px',
          ['--sidebar-w' as string]: '280px',
        }}
      >
        <div className="px-4 pb-12 md:px-8">
          {view === 'home' && (
            <HomePage
              topics={topics}
              videos={videos}
              topicMap={topicMap}
              loading={loading}
              error={error}
              search={search}
              lang={lang}
              onNavigate={navigate}
              onPlayVideo={() => navigate('videos')}
            />
          )}
          {view === 'general' && (
            <GeneralPage topics={topics} lang={lang} />
          )}
          {view === 'videos' && (
            <VideosPage
              videos={videos}
              topicMap={topicMap}
              lang={lang}
              loading={videosLoading}
            />
          )}
          {view === 'settings' && (
            <SettingsPage lang={lang} setLang={setLang} theme={theme} onToggleTheme={toggle} />
          )}
          {isPlaceholder && <PlaceholderPage view={view} />}
        </div>
      </main>
    </div>
  );
}

export default function App() {
  return (
    <I18nProvider>
      <Shell />
    </I18nProvider>
  );
}
