export type Topic = {
  id: string;
  slug: string;
  icon: string;
  color_from: string;
  color_to: string;
  sort_order: number;
  title_uz: string;
  title_en: string;
  description_uz: string;
  description_en: string;
};

export type Lesson = {
  id: string;
  topic_id: string;
  slug: string;
  sort_order: number;
  title_uz: string;
  title_en: string;
  summary_uz: string;
  summary_en: string;
  status: 'published' | 'coming_soon';
};

export type Video = {
  id: string;
  topic_id: string | null;
  title_uz: string;
  title_en: string;
  description_uz: string;
  description_en: string;
  youtube_id: string | null;
  duration_label: string | null;
  status: 'published' | 'coming_soon';
  sort_order: number;
};

export type Lang = 'uz' | 'en';

export type PageView =
  | 'home'
  | 'general'
  | 'videos'
  | 'quizzes'
  | 'games'
  | 'simulations'
  | 'labs'
  | 'library'
  | 'olympiads'
  | 'results'
  | 'settings'
  | 'help';
