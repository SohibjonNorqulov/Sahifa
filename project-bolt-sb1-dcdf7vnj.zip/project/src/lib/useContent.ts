import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import type { Topic, Lesson, Video } from '@/types/database';

export function useTopics() {
  const [topics, setTopics] = useState<Topic[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let active = true;
    (async () => {
      const { data, error } = await supabase
        .from('topics')
        .select('*')
        .order('sort_order');
      if (!active) return;
      if (error) setError(error.message);
      else setTopics(data ?? []);
      setLoading(false);
    })();
    return () => {
      active = false;
    };
  }, []);

  return { topics, loading, error };
}

export function useLessons(topicId: string | null) {
  const [lessons, setLessons] = useState<Lesson[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!topicId) {
      setLessons([]);
      return;
    }
    let active = true;
    setLoading(true);
    (async () => {
      const { data } = await supabase
        .from('lessons')
        .select('*')
        .eq('topic_id', topicId)
        .order('sort_order');
      if (!active) return;
      setLessons(data ?? []);
      setLoading(false);
    })();
    return () => {
      active = false;
    };
  }, [topicId]);

  return { lessons, loading };
}

export function useVideos() {
  const [videos, setVideos] = useState<Video[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let active = true;
    (async () => {
      const { data, error } = await supabase
        .from('videos')
        .select('*')
        .order('sort_order');
      if (!active) return;
      if (error) setError(error.message);
      else setVideos(data ?? []);
      setLoading(false);
    })();
    return () => {
      active = false;
    };
  }, []);

  return { videos, loading, error };
}
