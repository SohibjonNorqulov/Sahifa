import { useEffect, useState } from 'react';

type Theme = 'light' | 'dark';

function getInitial(): Theme {
  const saved = localStorage.getItem('phyuz-theme') as Theme | null;
  if (saved) return saved;
  return 'dark';
}

export function useTheme() {
  const [theme, setTheme] = useState<Theme>(getInitial);

  useEffect(() => {
    document.documentElement.setAttribute('data-theme', theme);
    localStorage.setItem('phyuz-theme', theme);
  }, [theme]);

  const toggle = () => setTheme((p) => (p === 'dark' ? 'light' : 'dark'));

  return { theme, toggle };
}
