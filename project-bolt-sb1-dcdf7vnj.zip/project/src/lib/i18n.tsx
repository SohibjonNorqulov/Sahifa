import { createContext, useContext, useState, type ReactNode } from 'react';
import type { Lang } from '@/types/database';

type Dict = Record<string, string>;

const uz: Dict = {
  searchPh: "Fizika mavzularini qidiring...",
  themeToggle: "Rejimni almashtirish",
  student: "O'quvchi",
  gMain: 'Asosiy',
  gContent: 'Kontent',
  gUser: 'Foydalanuvchi',
  gSystem: 'Tizim',
  home: 'Bosh sahifa',
  general: 'Umumiy fizika',
  videos: 'Video darslar',
  olympiads: 'Olimpiadalar',
  quizzes: 'Quizlar',
  games: 'Interaktiv o\'yinlar',
  simulations: 'Simulyatsiyalar',
  labs: 'Virtual laboratoriyalar',
  library: 'Kutubxona',
  results: 'Mening natijalarim',
  settings: 'Sozlamalar',
  help: 'Yordam',
  collapse: 'Yig\'ish',
  expand: 'Yoyish',
  heroTitle: 'Salom! Fizika olamiga xush kelibsiz',
  heroText:
    "Bu sayt fizikani o'zbek va ingliz tillarida o'rganmoqchi bo'lgan hamma uchun. Mavzular, video darslar, quizlar va simulyatsiyalar — barchasi bir joyda.",
  ctaStart: "O'rganishni boshlash",
  ctaQuiz: 'Quiz yechish',
  ctaVideos: 'Video darslarni ko\'rish',
  stLessons: 'Tugallangan darslar',
  stQuizzes: 'Yechilgan quizlar',
  stHours: "O'qish vaqti",
  stStreak: 'Ketma-ket kunlar',
  hrs: 'soat',
  days: 'kun',
  topicsTitle: 'Fizika bo\'limlari',
  topicsSub: "O'rganmoqchi bo'lgan bo'limingizni tanlang",
  viewAll: 'Barchasi',
  lessons: 'dars',
  noResults: "Hech narsa topilmadi. Boshqa so'z bilan qidirib ko'ring.",
  videosTitle: 'Video darslar',
  videosSub: "Yangi video darslar tez orada qo'shiladi",
  videoSoon: 'Video tez orada',
  videoPlay: "Ko'rish",
  progressTitle: 'Mening progressim',
  progressSub: "Har bir bo'lim bo'yicha natijalar",
  overall: 'Umumiy progress',
  overallSub: "Darslarni boshlang va natijangiz shu yerda ko'rinadi",
  aboutTitle: 'Biz haqimizda',
  aboutP1:
    "Salom! Bu veb-sayt O'zbekistondagi va xalqaro o'quvchilar uchun fizika fanini o'rganish va o'rgatish maqsadida yaratilmoqda.",
  aboutP2: "<b>Hozirgi mavzular:</b> SUVAT tenglamalari, harakat, kuchlar va o'lchovlar.",
  tagStudents: 'O\'quvchilar',
  tagUni: 'Talabalar',
  tagTeachers: 'O\'qituvchilar',
  tagBilingual: 'O\'zbekcha + English',
  generalSub:
    "Fizikaning asosiy bo'limlari. Har bir bo'limga mavzular, video darslar va topshiriqlar qo'shib boriladi.",
  subSoon: "+ Mavzular tez orada",
  progress: 'progress',
  settingsSub: 'Platformani o\'zingizga moslang',
  setLang: 'Til',
  setLangSub: 'Interfeys tili',
  setTheme: 'Mavzu (rejim)',
  setThemeSub: "Yorug' yoki qorong'i rejim",
  backHome: "Bosh sahifaga qaytish",
  soon: "Bu bo'lim tez orada ishga tushadi. Kontent tayyorlanmoqda.",
  slot: 'Bo\'sh joy',
  slotSub: "Kontent qo'shish uchun tayyor",
  published: 'Tayyor',
  comingSoon: 'Tez orada',
  loading: 'Yuklanmoqda...',
  error: 'Xatolik yuz berdi. Iltimos, qaytadan urinib ko\'ring.',
};

const en: Dict = {
  searchPh: 'Search physics topics...',
  themeToggle: 'Toggle dark mode',
  student: 'Student',
  gMain: 'Main',
  gContent: 'Content',
  gUser: 'User',
  gSystem: 'System',
  home: 'Home',
  general: 'General Physics',
  videos: 'Video Lessons',
  olympiads: 'Olympiads',
  quizzes: 'Quizzes',
  games: 'Interactive Games',
  simulations: 'Simulations',
  labs: 'Virtual Laboratories',
  library: 'Library',
  results: 'My Results',
  settings: 'Settings',
  help: 'Help',
  collapse: 'Collapse',
  expand: 'Expand',
  heroTitle: 'Hello! Welcome to the world of physics',
  heroText:
    'This website is for everyone who wants to learn physics in English and Uzbek. Topics, video lessons, quizzes and simulations — all in one place.',
  ctaStart: 'Start learning',
  ctaQuiz: 'Take a quiz',
  ctaVideos: 'Watch video lessons',
  stLessons: 'Lessons completed',
  stQuizzes: 'Quizzes solved',
  stHours: 'Study time',
  stStreak: 'Day streak',
  hrs: 'hrs',
  days: 'days',
  topicsTitle: 'Physics sections',
  topicsSub: 'Choose the section you want to study',
  viewAll: 'View all',
  lessons: 'lessons',
  noResults: 'Nothing found. Try a different search term.',
  videosTitle: 'Video lessons',
  videosSub: 'New video lessons are coming soon',
  videoSoon: 'Video coming soon',
  videoPlay: 'Watch',
  progressTitle: 'My progress',
  progressSub: 'Your results for each section',
  overall: 'Overall progress',
  overallSub: 'Start a lesson and your progress will appear here',
  aboutTitle: 'About us',
  aboutP1:
    'Hello! This website is being created to help students in Uzbekistan and around the world learn and teach physics.',
  aboutP2: '<b>Current topics:</b> SUVAT equations, motion, forces and measurements.',
  tagStudents: 'School students',
  tagUni: 'University students',
  tagTeachers: 'Teachers',
  tagBilingual: 'O\'zbekcha + English',
  generalSub:
    'The core branches of physics. Topics, video lessons and exercises will be added to each section.',
  subSoon: '+ Topics coming soon',
  progress: 'progress',
  settingsSub: 'Personalise the platform',
  setLang: 'Language',
  setLangSub: 'Interface language',
  setTheme: 'Theme',
  setThemeSub: 'Light or dark mode',
  backHome: 'Back to home',
  soon: 'This section is coming soon. Content is being prepared.',
  slot: 'Empty slot',
  slotSub: 'Ready for content',
  published: 'Ready',
  comingSoon: 'Coming soon',
  loading: 'Loading...',
  error: 'Something went wrong. Please try again.',
};

const dicts: Record<Lang, Dict> = { uz, en };

type I18nCtx = {
  lang: Lang;
  setLang: (l: Lang) => void;
  t: (key: string) => string;
};

const Ctx = createContext<I18nCtx | null>(null);

export function I18nProvider({ children }: { children: ReactNode }) {
  const [lang, setLangState] = useState<Lang>(
    () => (localStorage.getItem('phyuz-lang') as Lang) || 'uz'
  );

  const setLang = (l: Lang) => {
    setLangState(l);
    localStorage.setItem('phyuz-lang', l);
  };

  const t = (key: string) => dicts[lang][key] ?? key;

  return <Ctx.Provider value={{ lang, setLang, t }}>{children}</Ctx.Provider>;
}

export function useI18n() {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error('useI18n must be used within I18nProvider');
  return ctx;
}
