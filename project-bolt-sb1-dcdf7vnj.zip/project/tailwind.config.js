/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  darkMode: ['class', '[data-theme="dark"]'],
  theme: {
    extend: {
      colors: {
        bg: 'var(--c-bg)',
        surface: 'var(--c-surface)',
        'surface-2': 'var(--c-surface-2)',
        border: 'var(--c-border)',
        text: 'var(--c-text)',
        muted: 'var(--c-muted)',
        primary: 'var(--c-primary)',
        'primary-2': 'var(--c-primary-2)',
        'primary-soft': 'var(--c-primary-soft)',
        accent: 'var(--c-accent)',
        'accent-soft': 'var(--c-accent-soft)',
      },
      fontFamily: {
        sans: ['"Plus Jakarta Sans"', 'Arial', 'sans-serif'],
      },
      boxShadow: {
        card: 'var(--shadow-card)',
        hover: 'var(--shadow-hover)',
      },
      borderRadius: {
        xl2: '22px',
      },
    },
  },
  plugins: [],
};
