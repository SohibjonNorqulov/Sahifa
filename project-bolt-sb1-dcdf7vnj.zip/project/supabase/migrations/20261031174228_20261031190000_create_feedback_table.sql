/*
# Create public feedback inbox

1. New Tables
- `feedback` stores questions and suggestions submitted from the public PHYUZ website.
- `id` is the generated record identifier.
- `message` stores the student's message.
- `created_at` records when the message was submitted.

2. Security
- Row level security is enabled.
- Anonymous and signed-in visitors may submit a message only when it is non-empty and within the safe length limit.
- No browser role can read, update, or delete submitted feedback; the table is intended as a private owner inbox.
- The service role retains administrative access for future moderation workflows.

3. Important Notes
- No account is required to send feedback.
- The public website never receives the feedback list back after submission.
*/

CREATE TABLE IF NOT EXISTS public.feedback (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  message text NOT NULL CHECK (char_length(btrim(message)) BETWEEN 1 AND 2000),
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.feedback ENABLE ROW LEVEL SECURITY;

GRANT INSERT ON public.feedback TO anon, authenticated;
GRANT ALL ON public.feedback TO service_role;

DROP POLICY IF EXISTS "public_submit_feedback" ON public.feedback;
CREATE POLICY "public_submit_feedback" ON public.feedback
  FOR INSERT TO anon, authenticated
  WITH CHECK (char_length(btrim(message)) BETWEEN 1 AND 2000);
