/*
# PHYUZ — Physics Uzbekistan: initial schema

## Purpose
Stores the physics learning content (sections, lessons, video lessons) for the PHYUZ
platform. Content is bilingual (Uzbek + English) and fully editable from the database,
so the site owner can add or change lessons without touching code.

This is a single-tenant / public-content app: there is no sign-in. Everyone (including
the anon-key frontend) can read content. Writes are not exposed through RLS here —
content is managed directly in the database / dashboard.

## New Tables
1. `topics` — top-level physics sections (Mechanics, Optics, etc.)
   - id (uuid, pk)
   - slug (text, unique) — URL-safe identifier, e.g. "mechanics"
   - icon (text) — lucide-react icon name, e.g. "Atom"
   - color_from (text), color_to (text) — gradient endpoints (hex)
   - sort_order (int) — display order
   - title_uz (text), title_en (text)
   - description_uz (text), description_en (text)
   - created_at (timestamptz)

2. `lessons` — subtopics / lessons belonging to a topic
   - id (uuid, pk)
   - topic_id (uuid, fk -> topics)
   - slug (text)
   - sort_order (int)
   - title_uz, title_en (text)
   - summary_uz, summary_en (text)
   - status (text) — 'published' | 'coming_soon'
   - created_at (timestamptz)

3. `videos` — video lessons
   - id (uuid, pk)
   - topic_id (uuid, fk -> topics, nullable)
   - title_uz, title_en (text)
   - description_uz, description_en (text)
   - youtube_id (text, nullable) — YouTube video id for embedding
   - duration_label (text, nullable) — e.g. "12:34"
   - status (text) — 'published' | 'coming_soon'
   - sort_order (int)
   - created_at (timestamptz)

## Security
- RLS enabled on all tables.
- GRANT SELECT to anon + authenticated so the anon-key frontend can read all content.
- No INSERT/UPDATE/DELETE grants to anon — content is managed in the database directly.
- Policies use USING (true) for SELECT because the content is intentionally public.

## Notes
1. Seed data inserts the five original physics sections (Mechanics, Molecular,
   Electromagnetism, Optics, Atomic & Nuclear) plus placeholder lessons and videos.
2. Lessons and videos use ON DELETE CASCADE so removing a topic cleans up its children.
*/

CREATE TABLE IF NOT EXISTS topics (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  slug text UNIQUE NOT NULL,
  icon text NOT NULL DEFAULT 'Atom',
  color_from text NOT NULL DEFAULT '#1f6feb',
  color_to text NOT NULL DEFAULT '#3aa0ff',
  sort_order int NOT NULL DEFAULT 0,
  title_uz text NOT NULL,
  title_en text NOT NULL,
  description_uz text NOT NULL,
  description_en text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS lessons (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  topic_id uuid NOT NULL REFERENCES topics(id) ON DELETE CASCADE,
  slug text NOT NULL,
  sort_order int NOT NULL DEFAULT 0,
  title_uz text NOT NULL,
  title_en text NOT NULL,
  summary_uz text NOT NULL DEFAULT '',
  summary_en text NOT NULL DEFAULT '',
  status text NOT NULL DEFAULT 'coming_soon',
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS videos (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  topic_id uuid REFERENCES topics(id) ON DELETE SET NULL,
  title_uz text NOT NULL,
  title_en text NOT NULL,
  description_uz text NOT NULL DEFAULT '',
  description_en text NOT NULL DEFAULT '',
  youtube_id text,
  duration_label text,
  status text NOT NULL DEFAULT 'coming_soon',
  sort_order int NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE topics ENABLE ROW LEVEL SECURITY;
ALTER TABLE lessons ENABLE ROW LEVEL SECURITY;
ALTER TABLE videos ENABLE ROW LEVEL SECURITY;

GRANT SELECT ON topics TO anon, authenticated;
GRANT SELECT ON lessons TO anon, authenticated;
GRANT SELECT ON videos TO anon, authenticated;

DROP POLICY IF EXISTS "public_read_topics" ON topics;
CREATE POLICY "public_read_topics" ON topics FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "public_read_lessons" ON lessons;
CREATE POLICY "public_read_lessons" ON lessons FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "public_read_videos" ON videos;
CREATE POLICY "public_read_videos" ON videos FOR SELECT
  TO anon, authenticated USING (true);

-- Seed: topics
INSERT INTO topics (slug, icon, color_from, color_to, sort_order, title_uz, title_en, description_uz, description_en)
VALUES
  ('mechanics', 'Settings', '#1f6feb', '#3aa0ff', 1,
    'Mexanika', 'Mechanics',
    'Harakat, kuchlar, energiya va impuls qonunlari.',
    'Motion, forces, energy and momentum.'),
  ('molecular', 'FlaskConical', '#0ea5a4', '#34d3c5', 2,
    'Molekulyar fizika', 'Molecular Physics',
    'Modda tuzilishi, issiqlik va termodinamika.',
    'Structure of matter, heat and thermodynamics.'),
  ('electromagnetism', 'Zap', '#f5891f', '#ffb35c', 3,
    'Elektromagnetizm', 'Electromagnetism',
    'Elektr zaryadlar, tok, magnit maydon va induksiya.',
    'Electric charge, current, magnetic fields and induction.'),
  ('optics', 'Eye', '#7c4dff', '#a98bff', 4,
    'Optika', 'Optics',
    'Yorug''lik, linzalar, ko''zgular va to''lqin optikasi.',
    'Light, lenses, mirrors and wave optics.'),
  ('nuclear', 'Radiation', '#e5484d', '#ff7a7e', 5,
    'Atom va yadro fizikasi', 'Atomic & Nuclear Physics',
    'Atom tuzilishi, radioaktivlik va yadro reaksiyalari.',
    'Atomic structure, radioactivity and nuclear reactions.')
ON CONFLICT (slug) DO NOTHING;

-- Seed: lessons for mechanics
INSERT INTO lessons (topic_id, slug, sort_order, title_uz, title_en, summary_uz, summary_en, status)
SELECT id, 'suvat-equations', 1,
  'SUVAT tenglamalari', 'SUVAT Equations',
  'Tekabatlan harakatdagi tezlik, masofa va tezlanish bog''liqliklari.',
  'Relationships between velocity, distance and acceleration in uniform motion.',
  'coming_soon'
FROM topics WHERE slug = 'mechanics'
ON CONFLICT DO NOTHING;

INSERT INTO lessons (topic_id, slug, sort_order, title_uz, title_en, summary_uz, summary_en, status)
SELECT id, 'motion', 2,
  'Harakat turlari', 'Types of Motion',
  'To''g''ri chiziqli, aylanma va tebranma harakat.',
  'Linear, rotational and oscillatory motion.',
  'coming_soon'
FROM topics WHERE slug = 'mechanics'
ON CONFLICT DO NOTHING;

INSERT INTO lessons (topic_id, slug, sort_order, title_uz, title_en, summary_uz, summary_en, status)
SELECT id, 'forces', 3,
  'Kuchlar', 'Forces',
  'Nyuton qonunlari va kuchlar tahlili.',
  'Newton''s laws and force analysis.',
  'coming_soon'
FROM topics WHERE slug = 'mechanics'
ON CONFLICT DO NOTHING;

INSERT INTO lessons (topic_id, slug, sort_order, title_uz, title_en, summary_uz, summary_en, status)
SELECT id, 'measurements', 4,
  'O''lchovlar', 'Measurements',
  'SI birliklar, xatoliklar va o''lchash asoslari.',
  'SI units, errors and fundamentals of measurement.',
  'coming_soon'
FROM topics WHERE slug = 'mechanics'
ON CONFLICT DO NOTHING;

-- Seed: videos (placeholders)
INSERT INTO videos (topic_id, title_uz, title_en, description_uz, description_en, youtube_id, duration_label, status, sort_order)
SELECT id, 'SUVAT tenglamalari', 'SUVAT Equations',
  'Tekabatlan harakat tenglamalari video darsi.', 'Uniform motion equations video lesson.',
  NULL, NULL, 'coming_soon', 1
FROM topics WHERE slug = 'mechanics'
ON CONFLICT DO NOTHING;

INSERT INTO videos (topic_id, title_uz, title_en, description_uz, description_en, youtube_id, duration_label, status, sort_order)
SELECT id, 'Elektr tok kirish', 'Electric Current Intro',
  'Elektr zaryad va tok asoslari.', 'Basics of electric charge and current.',
  NULL, NULL, 'coming_soon', 2
FROM topics WHERE slug = 'electromagnetism'
ON CONFLICT DO NOTHING;

INSERT INTO videos (topic_id, title_uz, title_en, description_uz, description_en, youtube_id, duration_label, status, sort_order)
SELECT id, 'Yorug''lik va linzalar', 'Light and Lenses',
  'Linza va ko''zgar haqida video dars.', 'Video lesson on lenses and mirrors.',
  NULL, NULL, 'coming_soon', 3
FROM topics WHERE slug = 'optics'
ON CONFLICT DO NOTHING;
